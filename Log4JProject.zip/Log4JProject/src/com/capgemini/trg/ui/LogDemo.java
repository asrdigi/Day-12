package com.capgemini.trg.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LogDemo {
	private static Logger myLogger=Logger.getLogger(LogDemo.class);
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties"); 
		myLogger.debug("Debug message");
		myLogger.info("Informational message");
		System.out.println("Enter 2 integers: ");
		int n1=scanner.nextInt();
		int n2=scanner.nextInt();
		if(n2==0) {
			myLogger.error("Denominator cannot be 0");
		}else {
			int n3=n1/n2;
			myLogger.info("Divide operation successfull");
			System.out.println(n3);
		}

	}

}
