package com.capgemini.trg.service;

import static org.junit.Assert.assertNotNull;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTestFixture {
	
	@BeforeClass
	public static void initialize() {
		System.out.println("Initialization...");
	}
	
	@AfterClass
	public static void cleanup() {
		System.out.println("Cleanup...");
	}
	
	@Test
	public void testPerson() {
		System.out.println("From PersonTestFixture...");
		assertNotNull(new Person("Robert","King"));
	}
	
	
}
