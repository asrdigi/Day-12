package com.capgemini.trg.service;

import org.junit.Test;

public class PersonTest2 {
	
	@Test(expected=IllegalArgumentException.class)
	public void testNullsInName()		{
		System.out.println("From PersonTest2 testing "
				+ "exceptions");
		Person person = new Person(null,null);		
		}
}
