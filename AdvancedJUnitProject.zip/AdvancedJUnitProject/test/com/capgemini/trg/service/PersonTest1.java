package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class PersonTest1 {

	@Ignore
	@Test
	public void testPerson() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetFullName() {
		System.out.println("From PersonTest1 class");
		Person per = new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
	}

	@Test
	public void testGetFirstName() {
		System.out.println("From PersonTest1 class");
		Person per = new Person("Robert","King");
		assertEquals("Robert",per.getFirstName());
	}

	@Test
	public void testGetLastName() {
		System.out.println("From PersonTest1 class");
		Person per = new Person("Robert","King");
		assertEquals("King",per.getLastName());
	}

}
