package com.capgemini.trg.service;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public  class CalculatorUnitTest{
		private int operand1;
		private int operand2;
		
        @Parameterized.Parameters
        public static Collection data() {
        			return Arrays.asList(new Object[][] {
            							{25,5}, {100,6}, {50, 0}, 
            							{10, 4},{5,7}}
        								);
        }        

        public CalculatorUnitTest(int operand1, int operand2) {
            this.operand1=operand1;
            this.operand2=operand2;
        }

        @Test(expected=ArithmeticException.class)
        public void testMethod() {
        	System.out.println("Running testMethod() parameterized tests");         
            Assert.assertEquals(ArithmeticException.class, 
            						Calculator.divide(operand2));
        }
        
        @Test
        public void testSquared() {
        	System.out.println("Running testSquared() parameterized tests");
        	Assert.assertEquals(operand1*operand1,Calculator.squared(operand1));
        }
        
        @Test
        public void testMultiply() {
        	System.out.println("Running testMultiply() parameterized tests");
        	Assert.assertEquals(operand1*operand2, Calculator.multiply(operand1, operand2));
        }
}