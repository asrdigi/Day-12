package com.capgemini.trg.service;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class) 
@Suite.SuiteClasses({ PersonTest1.class, PersonTest2.class,
						PersonTestFixture.class}) 
public class TestPersonSuite {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Begining Test Suite");
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("The Test Suite is completed");
	}

}
