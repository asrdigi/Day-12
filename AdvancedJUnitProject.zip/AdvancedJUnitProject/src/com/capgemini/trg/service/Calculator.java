package com.capgemini.trg.service;

public class Calculator{
	public static int squared(int x){
		return x * x;
	}
	
	public static int divide(int divisor){
		int result=0;
		result=100/divisor;
		return result;
	}
	
	public static int multiply(int x, int y) {
		return x*y;
	}
}